function openForm() {
  document.getElementById("row").style.display = "block";
}

function closeForm() {
  document.getElementById("row").style.display = "none";
}