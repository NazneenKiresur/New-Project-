// const rmCheck = document.getElementById("check"),
//     userInput = document.getElementById("Uname");
//     userPassword = document.getElementById("Pass");

//     if (localStorage.checkbox && localStorage.checkbox !== "") {
//       rmCheck.setAttribute("checked", "checked");
//       userInput.value = localStorage.username;
//       userPassword.value = localStorage.password;
//     } else {
//       rmCheck.removeAttribute("checked");
//       userInput.value = "";
//       userPassword.value = "";
//     }

// var n = localStorage.getItem('on_load_counter');

// if (n === 1) {
//   n = 1;
// }
// n++;

// localStorage.setItem("on_load_counter", n);

// nums = n.toString().split('').map(Number);
// document.getElementById('CounterVisitor').innerHTML = '';
// for (var i of nums) {
//   document.getElementById('CounterVisitor').innerHTML += '<span class="counter-item">' + i + '</span>';
// }

// var visitcount = localStorage.getItem("page_view");
// if (visitcount){
//   visitcount=Number(visitcount)+1;
//   localStorage.setItem("page_view", visitcount);
// }
// else{
//   visitcount=1;
//   localStorage.setItem("page_view",1)
// }
// console.log(visitcount);


function setcookie() {
  var username = document.getElementById("Uname").value;
  var password = document.getElementById("Pass").value;

  document.cookie = "myusername=" + username + ";path=http://127.0.0.1:5501/login.html"
  document.cookie = "mypassword=" + password + ";path=http://127.0.0.1:5501/login.html"
}

function getcookiedata() {
  console.log(document.cookie);
  var userdata = getcookie('myusername');
  var passworddata = getcookie('mypassword');

  document.getElementById("Uname").value = userdata
  document.getElementById("Pass").value = passworddata

}

function getcookie(cname) {
  var name = cname + " =";
  var decodecookiee = decodeURIComponent(document.cookie);
  var ca = decodecookiee.split(";");
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function checkUserName() {
  const userNamePattern = /[a-zA-z]{8,15}/;
  const userName = document.querySelector("#Uname");

  return userNamePattern.test(userName.value);
}

function checkPassword() {
  const passwordpattern =
    /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\S+$).{8,}$/;
  const userpass = document.querySelector("#Pass");

  return passwordpattern.test(userpass.value);
}

function linking() {


}

async function signin() {
  var name = document.getElementById("Uname").value;

  var password = document.getElementById("Pass").value;

  let user = { username: name, password: password };

  try {
    const response = await axios.post(
      "http://localhost:8080/api/auth/signin",
      user
    );
    sessionStorage.setItem("userInfo", JSON.stringify(response.data));
    console.log(sessionStorage.getItem("userInfo"));
    console.log(response.data.roles);
    if (response.data.roles[0] == "ROLE_ADMIN") {
      window.location.replace("http://localhost:8081");
    }
    else {
      window.location.href = "../event.html";
    }
  } catch (error) {
    console.log(error);
    // if (error.response) {
    //   console.log(error.reponse.status);
    // } else {
    //   console.log(error.message);
    // }
  }
}

function handle(event) {
  event.preventDefault();
  //   if (!checkUserName()) {
  //     alert("Enter a valid username");
  //     return;
  //   }
  if (!checkPassword()) {
    alert("Enter a valid password");
    return;
  }

  signin();

  linking();
}
document.getElementById("log").addEventListener("click", handle);
